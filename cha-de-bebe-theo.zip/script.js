
document.getElementById("rsvpForm").addEventListener("submit", function(e) {
  e.preventDefault();
  
  const name = document.getElementById("name").value;
  const guests = document.getElementById("guests").value;

  document.getElementById("confirmationMessage").textContent = 
    `Obrigado, ${name}! Sua presença com ${guests} pessoa(s) foi confirmada.`;
});
